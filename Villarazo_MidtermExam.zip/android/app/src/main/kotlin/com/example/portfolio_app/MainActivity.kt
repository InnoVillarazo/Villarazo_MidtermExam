package com.example.portfolio_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
